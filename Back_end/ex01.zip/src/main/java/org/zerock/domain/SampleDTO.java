package org.zerock.domain;

import lombok.Data;

@Data
public class SampleDTO { //Data Transfer Object

  private String name;
  private int age;
  
  
  // getter, setter, equals(), toString(), ������
}
