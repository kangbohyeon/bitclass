import React from 'react';
import ReactstrapTab from './R055_ReactstrapTab'
import 'bootstrap/dist/css/bootstrap.css'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <ReactstrapTab/>
    </div>
  );
}

export default App;
