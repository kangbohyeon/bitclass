import React from 'react';
import Sweetalert2Position from './R057_Sweetalert2Position'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <Sweetalert2Position/>
    </div>
  );
}

export default App;