import React from 'react';
import Sweetalert2Basic from './R056_Sweetalert2Basic'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <Sweetalert2Basic/>
    </div>
  );
}

export default App;