import React from 'react';
import FetchPost from './R060_FetchPost'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <FetchPost/>
    </div>
  );
}

export default App;