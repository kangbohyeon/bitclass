import React from 'react';
import Progress from './R052_ReactstrapProgress'
import 'bootstrap/dist/css/bootstrap.css'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <Progress/>
    </div>
  );
}

export default App;