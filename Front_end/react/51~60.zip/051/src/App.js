import React from 'react';
import Popover from './R051_ReactstrapPopover'
import 'bootstrap/dist/css/bootstrap.css'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <Popover/>
    </div>
  );
}

export default App;