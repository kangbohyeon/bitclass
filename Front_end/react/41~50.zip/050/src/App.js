import React from 'react';
import Pagination from './R050_ReactstrapPagination'
import 'bootstrap/dist/css/bootstrap.css'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <Pagination/>
    </div>
  );
}

export default App;