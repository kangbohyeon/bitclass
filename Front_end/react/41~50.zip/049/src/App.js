import React from 'react';
import Navbar from './R049_ReactstrapNavbar'
import 'bootstrap/dist/css/bootstrap.css'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <Navbar/>
    </div>
  );
}

export default App;