import React from 'react';
// import './App.css';
import ReactstrapCarousel from './R041_ReactstrapCarousel'
import 'bootstrap/dist/css/bootstrap.css'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <p>CSS 적용하기</p>
      <ReactstrapCarousel/>
    </div>
  );
}

export default App;