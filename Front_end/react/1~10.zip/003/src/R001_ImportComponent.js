import React, { Component } from 'react';

class R001_ImportComponent extends Component {
  render () {
    return (
      <h2>[ THIS IS IMPORTED COMPONENT ]</h2>
    )
  }
}

export default R001_ImportComponent;