import React from 'react';
import './App.css';
import Es6 from './R009_Es6'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <p>CSS 적용하기</p>
      <Es6/>
    </div>
  );
}

export default App;