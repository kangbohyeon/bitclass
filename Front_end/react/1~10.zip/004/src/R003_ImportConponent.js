import React, { Component } from 'react';

class R003_ImportConponent extends Component {
  render () {
    return (
      <h2>[ THIS IS IMPORTED COMPONENT ]</h2>
    )
  }
}

export default R003_ImportConponent;