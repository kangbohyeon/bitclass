import React from 'react';
import './App.css';
import Variable from './R010_Variable'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <p>CSS 적용하기</p>
      <Variable/>
    </div>
  );
}

export default App;