import React from 'react';
import ReactonSubmit from './R072_onSubmit'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <ReactonSubmit/>
    </div>
  );
}

export default App;