import React from 'react';
import ReactOnKey from './R071_OnKey'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <ReactOnKey/>
    </div>
  );
}

export default App;