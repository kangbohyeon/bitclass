import React from 'react';
import Currying from './R074_ReactCurrying'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <Currying/>
    </div>
  );
}

export default App;