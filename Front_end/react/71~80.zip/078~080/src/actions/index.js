export const ADD = 'ADD';
export const add = () => {
    return {
        type: ADD
    }
};
