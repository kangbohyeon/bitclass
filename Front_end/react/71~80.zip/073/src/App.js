import React from 'react';
import ReactRef from './R073_ReactRef'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <ReactRef/>
    </div>
  );
}

export default App;