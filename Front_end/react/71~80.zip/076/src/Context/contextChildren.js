import React from 'react'
import Children2  from "./contextChildren2";

class contextChildren extends React.Component {
    render () {
      return (
        <Children2 />
      )
    }
}
export default contextChildren