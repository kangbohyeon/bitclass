import React from 'react';
import HocComponent from "./Hoc/R075_ReactHoc";

function R075_ReactHoc() {
  return (
    <div className="App">
      <HocComponent name='React200'/>
    </div>
  );
}
export default R075_ReactHoc;