import React from 'react';
import ReactHoc from './Hoc/R075_ReactHoc'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <ReactHoc name='React200'/>
    </div>
  );
}

export default App;