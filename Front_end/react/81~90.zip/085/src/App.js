import React from 'react';
import CookieSave from './R085_cookieSave'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <CookieSave/>
    </div>
  );
}

export default App;