import React, { Component } from 'react';

class R089_reactRouter2 extends Component {
  render() {
    return (
      <>
        <h1>path='/reactRouter2'</h1>
        <h3>R089_reactRouter</h3>
      </>
    )
  }
}

export default R089_reactRouter2;