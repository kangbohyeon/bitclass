import React, { Component } from 'react';

class R089_reactRouter extends Component {
  render() {
    return (
      <>
        <h1>path='/'</h1>
        <h3>R089_reactRouter</h3>
      </>
    )
  }
}

export default R089_reactRouter;