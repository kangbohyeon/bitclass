import React from 'react';
import './App.css';
import ReactstrapDropdown from './R037_ReactstrapDropdown'
import 'bootstrap/dist/css/bootstrap.css'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <p>CSS 적용하기</p>
      <ReactstrapDropdown/>
    </div>
  );
}

export default App;
