import React, { Component } from 'react';

class R032_Fragments extends Component {
  render() {
    return (
      <>
        <p>P TAG</p>
        <span>SPAN TAG</span>
      </>
    )
  }
}

export default R032_Fragments;