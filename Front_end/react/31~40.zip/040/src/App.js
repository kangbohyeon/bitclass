import React from 'react';
// import './App.css';
import ReactstrapCard from './R040_ReactstrapCard'
import 'bootstrap/dist/css/bootstrap.css'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <p>CSS 적용하기</p>
      <ReactstrapCard/>
    </div>
  );
}

export default App;