import React from 'react';
import Promise from './R064_Promise'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <Promise/>
    </div>
  );
}

export default App;