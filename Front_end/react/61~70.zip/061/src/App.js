import React from 'react';
import AxiosGet from './R061_AxiosGet'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <AxiosGet/>
    </div>
  );
}

export default App;