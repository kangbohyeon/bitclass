import React from 'react';
import ReactChange from './R067_onChange'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <ReactChange/>
    </div>
  );
}

export default App;