import React from 'react';
import ReactMouseOut from './R070_onMouseOut'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <ReactMouseOut/>
    </div>
  );
}

export default App;