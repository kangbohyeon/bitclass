import React from 'react';
import AxiosPost from './R062_AxiosPost'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <AxiosPost/>
    </div>
  );
}

export default App;