import React from 'react';
import ReactMouseOver from './R069_onMouseOver'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <ReactMouseOver/>
    </div>
  );
}

export default App;