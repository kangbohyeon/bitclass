import React from 'react';
import ReactonClick from './R066_onClick'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <ReactonClick/>
    </div>
  );
}

export default App;