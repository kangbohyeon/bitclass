import React from 'react';
import CallbackFunc from './R063_CallbackFunc'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <CallbackFunc/>
    </div>
  );
}

export default App;