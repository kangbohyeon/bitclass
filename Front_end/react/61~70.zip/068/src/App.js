import React from 'react';
import ReactMouseMove from './R068_onMouseMove'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <ReactMouseMove/>
    </div>
  );
}

export default App;