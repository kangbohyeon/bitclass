import React from 'react';
import './App.css';
import ForceUpdate from './R026_ForceUpdate'

function App() {
  return (
    <div>
      <h1>Start React 200!</h1>
      <p>CSS 적용하기</p>
      <ForceUpdate/>
    </div>
  );
}

export default App;