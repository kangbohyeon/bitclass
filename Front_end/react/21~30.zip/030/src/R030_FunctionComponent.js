import React from 'react';

function R030_FunctionComponent(props){
  let { contents } = props;
  return (
    <h2>{contents}</h2>
  )
}

export default R030_FunctionComponent;